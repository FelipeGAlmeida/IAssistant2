package fgapps.com.br.iassistant2

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.felipecsl.gifimageview.library.GifImageView
import kotlinx.android.synthetic.main.activity_main.*
import java.io.IOException

class MainActivity : AppCompatActivity() {

//    var background_gif: GifImageView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setBackground();
    }

    private fun setBackground() {
        var background_gif = background_id;
        Glide.with(this)
                .load(R.drawable.back_anim1)
                .into(background_gif);
    }
}
